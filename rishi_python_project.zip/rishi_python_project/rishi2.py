"""
╔══════════════════════════════════════════════╗
║   PharmaSys — Pharmacy Management System     ║
║   • SQLite persistent storage (pharma_data.db)
║   • Bar chart + Pie chart (matplotlib)       ║
║   • Warm dark aesthetic UI                   ║
╚══════════════════════════════════════════════╝
 
Install dependencies:
    pip install matplotlib
 
Run:
    python pharmacy_management.py
"""
 
import tkinter as tk
from tkinter import messagebox, ttk
import sqlite3
import datetime
import os
 
# ── matplotlib (optional — graceful fallback if missing) ─────
try:
    import matplotlib
    matplotlib.use("TkAgg")
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    from matplotlib.figure import Figure
    HAS_MPL = True
except ImportError:
    HAS_MPL = False
 
# ════════════════════════════════════════════════════════════
#  PALETTE — warm dark (charcoal + gold + sage)
# ════════════════════════════════════════════════════════════
BG       = "#1C1C1E"   # near-black
CARD     = "#2A2A2D"   # panel bg
CARD2    = "#313135"   # input bg
BORDER   = "#3A3A3E"
ACCENT   = "#E8C07D"   # warm gold
SAGE     = "#7EB8A4"   # sage green
ROSE     = "#D4847A"   # muted red
TEXT     = "#F0EDE8"   # warm white
SUBTEXT  = "#8E8C88"
 
CHART_COLORS = ["#E8C07D","#7EB8A4","#D4847A","#9B8EC4",
                "#6BA3BE","#D4A76A","#87B88A","#C87E8A"]
 
F_H1   = ("Georgia",  16, "bold")
F_H2   = ("Georgia",  12, "bold")
F_BODY = ("Helvetica",10)
F_BOLD = ("Helvetica",10, "bold")
F_SM   = ("Helvetica", 9)
F_MONO = ("Courier",  10)
 
# ════════════════════════════════════════════════════════════
#  DATABASE  (same folder as script — data persists forever)
# ════════════════════════════════════════════════════════════
# DB column order:
#   0:id  1:name  2:company  3:category  4:price  5:discount
#   6:discount_amt  7:total  8:stock  9:mfg  10:exp
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pharma_data.db")
 
def _conn():
    con = sqlite3.connect(DB_PATH)
    con.execute("""CREATE TABLE IF NOT EXISTS medicines(
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        name         TEXT    NOT NULL,
        company      TEXT    DEFAULT '',
        category     TEXT    DEFAULT '',
        price        REAL    DEFAULT 0,
        discount     REAL    DEFAULT 0,
        discount_amt REAL    DEFAULT 0,
        total        REAL    DEFAULT 0,
        stock        INTEGER DEFAULT 0,
        mfg          TEXT    DEFAULT '',
        exp          TEXT    DEFAULT ''
    )""")
    con.commit()
    return con
 
def db_all():
    with _conn() as c:
        return c.execute("SELECT * FROM medicines ORDER BY id").fetchall()
 
def db_search(kw):
    p = f"%{kw}%"
    with _conn() as c:
        return c.execute(
            "SELECT * FROM medicines WHERE name LIKE ? OR company LIKE ? OR category LIKE ?",
            (p, p, p)).fetchall()
 
def db_add(m):
    with _conn() as c:
        c.execute(
            "INSERT INTO medicines(name,company,category,price,discount,"
            "discount_amt,total,stock,mfg,exp) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (m["name"], m["company"], m["category"],
             m["price"], m["discount"], m["disc_amt"], m["total"],
             m["stock"], m["mfg"], m["exp"]))
 
def db_update(rid, m):
    with _conn() as c:
        c.execute(
            "UPDATE medicines SET name=?,company=?,category=?,price=?,discount=?,"
            "discount_amt=?,total=?,stock=?,mfg=?,exp=? WHERE id=?",
            (m["name"], m["company"], m["category"],
             m["price"], m["discount"], m["disc_amt"], m["total"],
             m["stock"], m["mfg"], m["exp"], rid))
 
def db_delete(rid):
    with _conn() as c:
        c.execute("DELETE FROM medicines WHERE id=?", (rid,))
 
# ════════════════════════════════════════════════════════════
#  HELPERS
# ════════════════════════════════════════════════════════════
def calc(price, disc):
    da = round(price * disc / 100, 2)
    return da, round(price - da, 2)
 
def btn(parent, text, cmd, bg, fg=TEXT, w=22):
    return tk.Button(parent, text=text, command=cmd,
                     bg=bg, fg=fg, activebackground=bg, activeforeground=fg,
                     font=F_BOLD, relief="flat", cursor="hand2",
                     padx=6, pady=8, width=w, bd=0)
 
def divider(parent):
    tk.Frame(parent, bg=BORDER, height=1).pack(fill="x", padx=16, pady=6)
 
# ════════════════════════════════════════════════════════════
#  MAIN APPLICATION
# ════════════════════════════════════════════════════════════
class App:
    def __init__(self, root):
        self.root   = root
        self.sel_id = None          # currently selected DB row id
 
        root.title("PharmaSys — Medicine Inventory")
        root.geometry("1380x800")
        root.minsize(1100, 660)
        root.configure(bg=BG)
 
        self._styles()
        self._header()
        self._tabs()
        self.refresh()
 
    # ── ttk styles ───────────────────────────────────────────
    def _styles(self):
        s = ttk.Style()
        s.theme_use("clam")
 
        s.configure("TNotebook",     background=BG,   borderwidth=0)
        s.configure("TNotebook.Tab", background=CARD, foreground=SUBTEXT,
                    font=F_BOLD, padding=[18, 8])
        s.map("TNotebook.Tab",
              background=[("selected", ACCENT)],
              foreground=[("selected", BG)])
 
        s.configure("T.Treeview",
                    background=CARD, foreground=TEXT,
                    fieldbackground=CARD, rowheight=28,
                    font=F_BODY, borderwidth=0)
        s.configure("T.Treeview.Heading",
                    background=CARD2, foreground=ACCENT,
                    font=F_BOLD, relief="flat")
        s.map("T.Treeview",
              background=[("selected", ACCENT)],
              foreground=[("selected", BG)])
 
        s.configure("TCombobox",
                    fieldbackground=CARD2, background=CARD2,
                    foreground=TEXT, selectbackground=ACCENT,
                    selectforeground=BG)
        s.map("TCombobox",
              fieldbackground=[("readonly", CARD2)],
              foreground=[("readonly", TEXT)])
 
    # ── header ───────────────────────────────────────────────
    def _header(self):
        bar = tk.Frame(self.root, bg=CARD, height=52)
        bar.pack(fill="x")
        bar.pack_propagate(False)
 
        tk.Frame(bar, bg=ACCENT, width=5).pack(side="left", fill="y")
        tk.Label(bar, text="💊  PharmaSys",
                 font=("Georgia", 18, "bold"),
                 bg=CARD, fg=ACCENT).pack(side="left", padx=(14, 6))
        tk.Label(bar, text="Medicine Inventory Manager",
                 font=F_BODY, bg=CARD, fg=SUBTEXT).pack(side="left")
 
        self.lbl_clock = tk.Label(bar, font=F_MONO, bg=CARD, fg=SUBTEXT)
        self.lbl_clock.pack(side="right", padx=18)
        self._tick()
 
    def _tick(self):
        self.lbl_clock.config(
            text=datetime.datetime.now().strftime("  %d %b %Y   %H:%M:%S  "))
        self.root.after(1000, self._tick)
 
    # ── notebook tabs ────────────────────────────────────────
    def _tabs(self):
        nb = ttk.Notebook(self.root)
        nb.pack(fill="both", expand=True, padx=8, pady=8)
 
        t1 = tk.Frame(nb, bg=BG)
        t2 = tk.Frame(nb, bg=BG)
        nb.add(t1, text="  📋  Inventory  ")
        nb.add(t2, text="  📊  Analytics  ")
 
        # auto-refresh charts when tab is switched
        nb.bind("<<NotebookTabChanged>>",
                lambda e: self._draw_charts() if nb.index("current") == 1 else None)
 
        self._inventory_tab(t1)
        self._analytics_tab(t2)
 
    # ════════════════════════════════════════════════════════
    #  TAB 1 — INVENTORY
    # ════════════════════════════════════════════════════════
    def _inventory_tab(self, parent):
        left  = tk.Frame(parent, bg=CARD, width=345)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)
 
        right = tk.Frame(parent, bg=BG)
        right.pack(side="left", fill="both", expand=True, padx=(6, 0))
 
        self._form(left)
        self._table_panel(right)
 
    # ── input form ───────────────────────────────────────────
    def _form(self, p):
        tk.Label(p, text="Medicine Details",
                 font=F_H2, bg=CARD, fg=ACCENT).pack(
                 pady=(16, 4), padx=18, anchor="w")
        divider(p)
 
        # scrollable inner canvas
        cv = tk.Canvas(p, bg=CARD, bd=0, highlightthickness=0)
        cv.pack(fill="both", expand=True)
 
        inner = tk.Frame(cv, bg=CARD)
        cv.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>",
                   lambda e: cv.configure(scrollregion=cv.bbox("all")))
 
        # variables
        self.v_name  = tk.StringVar()
        self.v_co    = tk.StringVar()
        self.v_cat   = tk.StringVar()
        self.v_price = tk.StringVar()
        self.v_disc  = tk.StringVar(value="0")
        self.v_stock = tk.StringVar()
        self.v_mfg   = tk.StringVar(value=str(datetime.date.today()))
        self.v_exp   = tk.StringVar()
        self.v_srch  = tk.StringVar()
 
        def lbl(t):
            tk.Label(inner, text=t, font=F_BOLD,
                     bg=CARD, fg=SUBTEXT).pack(anchor="w", padx=18, pady=(8, 1))
 
        def field(var):
            e = tk.Entry(inner, textvariable=var,
                         bg=CARD2, fg=TEXT,
                         insertbackground=ACCENT, relief="flat",
                         font=F_BODY, highlightthickness=1,
                         highlightcolor=ACCENT, highlightbackground=BORDER)
            e.pack(fill="x", padx=18, ipady=7, pady=(0, 2))
 
        def combo(var, vals):
            cb = ttk.Combobox(inner, textvariable=var,
                              values=vals, font=F_BODY, state="normal")
            cb.pack(fill="x", padx=18, ipady=5, pady=(0, 2))
 
        lbl("Medicine Name  *");      field(self.v_name)
        lbl("Company / Brand");       field(self.v_co)
        lbl("Category");              combo(self.v_cat,
            ["Antibiotic","Painkiller","Antacid","Vitamin",
             "Antifungal","Antiviral","Cardiovascular",
             "Diabetes","Syrup","Injection","Other"])
 
        # 3-column row: price / disc / stock
        row3 = tk.Frame(inner, bg=CARD)
        row3.pack(fill="x", padx=18, pady=(10, 2))
        for lbl3, var, w in [("Price ₹", self.v_price, 9),
                               ("Disc %",  self.v_disc,  7),
                               ("Stock",   self.v_stock, 6)]:
            col = tk.Frame(row3, bg=CARD)
            col.pack(side="left", expand=True, fill="x", padx=(0, 6))
            tk.Label(col, text=lbl3, font=("Helvetica", 9, "bold"),
                     bg=CARD, fg=SUBTEXT).pack(anchor="w")
            tk.Entry(col, textvariable=var, bg=CARD2, fg=TEXT,
                     insertbackground=ACCENT, relief="flat",
                     font=F_BODY, highlightthickness=1,
                     highlightcolor=ACCENT, highlightbackground=BORDER,
                     width=w).pack(fill="x", ipady=7)
 
        lbl("Mfg Date  (YYYY-MM-DD)"); field(self.v_mfg)
        lbl("Exp Date  (YYYY-MM-DD)"); field(self.v_exp)
 
        # live price summary
        self.v_price.trace_add("write", self._live)
        self.v_disc .trace_add("write", self._live)
 
        strip = tk.Frame(inner, bg="#252528", pady=8)
        strip.pack(fill="x", padx=18, pady=(12, 4))
        self.lbl_da  = tk.Label(strip, text="Discount:  ₹0.00",
                                 font=F_SM, bg="#252528", fg=ACCENT)
        self.lbl_da.pack(side="left", padx=12)
        self.lbl_tot = tk.Label(strip, text="Net Total:  ₹0.00",
                                 font=F_BOLD, bg="#252528", fg=SAGE)
        self.lbl_tot.pack(side="right", padx=12)
 
        divider(inner)
 
        # action buttons
        bf = tk.Frame(inner, bg=CARD)
        bf.pack(fill="x", padx=18, pady=(2, 18))
        for text, cmd, bg, fg in [
            ("✅  Add Medicine",      self.add,    SAGE,    BG),
            ("✏️  Update Selected",  self.update, ACCENT,  BG),
            ("🗑️  Delete Selected",  self.delete, ROSE,    TEXT),
            ("✖   Clear Form",       self.clear,  CARD2,   SUBTEXT),
        ]:
            btn(bf, text, cmd, bg, fg, w=26).pack(fill="x", pady=3)
 
    # ── table panel ──────────────────────────────────────────
    def _table_panel(self, p):
        # search bar
        sbar = tk.Frame(p, bg=CARD, pady=8)
        sbar.pack(fill="x", pady=(0, 6))
 
        tk.Label(sbar, text="🔍", font=("Helvetica", 12),
                 bg=CARD, fg=SUBTEXT).pack(side="left", padx=(12, 4))
        srch = tk.Entry(sbar, textvariable=self.v_srch,
                        bg=CARD2, fg=TEXT, insertbackground=ACCENT,
                        relief="flat", font=F_BODY,
                        highlightthickness=1, highlightcolor=ACCENT,
                        highlightbackground=BORDER)
        srch.pack(side="left", fill="x", expand=True, ipady=5, padx=(0, 8))
        srch.bind("<KeyRelease>", self._search)
 
        btn(sbar, "Show All", self.refresh, CARD2, SUBTEXT, w=10).pack(
            side="left", padx=(0, 10))
 
        # stats
        self.lbl_stats = tk.Label(p, text="", font=F_SM,
                                   bg=BG, fg=SUBTEXT, anchor="w")
        self.lbl_stats.pack(fill="x", padx=6, pady=(0, 4))
 
        # treeview
        cols = ("ID", "Name", "Company", "Category",
                "Price ₹", "Disc %", "Disc Amt ₹", "Net Total ₹",
                "Stock", "Mfg Date", "Exp Date")
        widths = [38, 160, 130, 110, 80, 62, 90, 95, 58, 100, 100]
 
        frm = tk.Frame(p, bg=BG)
        frm.pack(fill="both", expand=True)
 
        vsb = ttk.Scrollbar(frm, orient="vertical")
        hsb = ttk.Scrollbar(frm, orient="horizontal")
 
        self.tree = ttk.Treeview(frm, columns=cols, show="headings",
                                  style="T.Treeview",
                                  yscrollcommand=vsb.set,
                                  xscrollcommand=hsb.set)
        vsb.config(command=self.tree.yview)
        hsb.config(command=self.tree.xview)
 
        for col, w in zip(cols, widths):
            self.tree.heading(col, text=col,
                              command=lambda c=col: self._sort(c))
            self.tree.column(col, width=w, anchor="center", minwidth=38)
 
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)
 
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
 
    # ════════════════════════════════════════════════════════
    #  TAB 2 — ANALYTICS
    # ════════════════════════════════════════════════════════
    def _analytics_tab(self, parent):
        topbar = tk.Frame(parent, bg=CARD, pady=10)
        topbar.pack(fill="x")
 
        tk.Label(topbar, text="Analytics Dashboard",
                 font=F_H2, bg=CARD, fg=ACCENT).pack(side="left", padx=16)
 
        btn(topbar, "🔄  Refresh Charts",
            self._draw_charts, SAGE, BG, w=16).pack(side="right", padx=14)
 
        self.chart_host = tk.Frame(parent, bg=BG)
        self.chart_host.pack(fill="both", expand=True, padx=10, pady=10)
 
        tk.Label(self.chart_host,
                 text="Charts load automatically when you open this tab.",
                 font=F_BODY, bg=BG, fg=SUBTEXT).pack(expand=True)
 
    def _draw_charts(self):
        for w in self.chart_host.winfo_children():
            w.destroy()
 
        if not HAS_MPL:
            tk.Label(self.chart_host,
                     text="matplotlib not installed.\nRun:  pip install matplotlib",
                     font=F_H2, bg=BG, fg=ROSE).pack(expand=True)
            return
 
        rows = db_all()
        if not rows:
            tk.Label(self.chart_host,
                     text="No data yet — add medicines to see charts!",
                     font=F_BODY, bg=BG, fg=SUBTEXT).pack(expand=True)
            return
 
        # aggregate per category
        # DB: 0=id 1=name 2=co 3=cat 4=price 5=disc 6=disc_amt 7=total 8=stock 9=mfg 10=exp
        cats = {}
        for r in rows:
            cat = r[3] or "Unknown"
            cats.setdefault(cat, {"stock": 0, "revenue": 0})
            cats[cat]["stock"]   += (r[8] or 0)
            cats[cat]["revenue"] += (r[7] or 0)
 
        labels   = list(cats.keys())
        stocks   = [cats[c]["stock"]   for c in labels]
        revenues = [cats[c]["revenue"] for c in labels]
        colors   = CHART_COLORS[:len(labels)]
 
        # matplotlib dark theme matching app
        import matplotlib.pyplot as plt
        plt.rcParams.update({
            "figure.facecolor" : BG,
            "axes.facecolor"   : CARD,
            "axes.edgecolor"   : BORDER,
            "axes.spines.top"  : False,
            "axes.spines.right": False,
            "text.color"       : TEXT,
            "axes.labelcolor"  : SUBTEXT,
            "xtick.color"      : SUBTEXT,
            "ytick.color"      : SUBTEXT,
            "grid.color"       : BORDER,
            "grid.linestyle"   : "--",
            "grid.alpha"       : 0.35,
        })
 
        fig = Figure(figsize=(14, 5.5), facecolor=BG)
        fig.subplots_adjust(wspace=0.35, left=0.06, right=0.97,
                            top=0.88, bottom=0.20)
 
        def nice(ax):
            ax.set_facecolor(CARD)
            ax.grid(axis="y")
            ax.tick_params(axis="x", rotation=28, labelsize=9)
            ax.tick_params(axis="y", labelsize=9)
 
        # bar 1 — stock
        ax1 = fig.add_subplot(1, 3, 1)
        bars1 = ax1.bar(labels, stocks, color=colors,
                        edgecolor=BG, linewidth=0.6, width=0.55)
        ax1.set_title("Stock by Category", color=ACCENT,
                      fontsize=11, fontweight="bold", pad=10)
        ax1.set_ylabel("Units", color=SUBTEXT, fontsize=9)
        nice(ax1)
        mx = max(stocks) if stocks else 1
        for b, v in zip(bars1, stocks):
            if v > 0:
                ax1.text(b.get_x() + b.get_width()/2,
                         b.get_height() + mx*0.02,
                         str(v), ha="center", va="bottom",
                         color=TEXT, fontsize=8, fontweight="bold")
 
        # bar 2 — revenue
        ax2 = fig.add_subplot(1, 3, 2)
        bars2 = ax2.bar(labels, revenues, color=colors,
                        edgecolor=BG, linewidth=0.6, width=0.55)
        ax2.set_title("Revenue by Category (₹)", color=ACCENT,
                      fontsize=11, fontweight="bold", pad=10)
        ax2.set_ylabel("Value (₹)", color=SUBTEXT, fontsize=9)
        nice(ax2)
        mx2 = max(revenues) if revenues else 1
        for b, v in zip(bars2, revenues):
            if v > 0:
                ax2.text(b.get_x() + b.get_width()/2,
                         b.get_height() + mx2*0.02,
                         f"₹{v:.0f}", ha="center", va="bottom",
                         color=TEXT, fontsize=8, fontweight="bold")
 
        # pie — stock share
        ax3 = fig.add_subplot(1, 3, 3)
        wedges, texts, autos = ax3.pie(
            stocks, labels=labels,
            colors=colors, explode=[0.04]*len(labels),
            autopct="%1.1f%%", startangle=120,
            pctdistance=0.78,
            wedgeprops=dict(edgecolor=BG, linewidth=1.8))
        for t in texts:  t.set_color(TEXT); t.set_fontsize(9)
        for t in autos:
            t.set_color(BG); t.set_fontsize(8); t.set_fontweight("bold")
        ax3.set_title("Stock Share (%)", color=ACCENT,
                      fontsize=11, fontweight="bold", pad=10)
 
        canvas = FigureCanvasTkAgg(fig, master=self.chart_host)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)
 
    # ════════════════════════════════════════════════════════
    #  BUSINESS LOGIC
    # ════════════════════════════════════════════════════════
    def _live(self, *_):
        """Update discount / total preview while typing."""
        try:
            da, tot = calc(float(self.v_price.get()),
                           float(self.v_disc.get()))
            self.lbl_da .config(text=f"Discount:  ₹{da:,.2f}")
            self.lbl_tot.config(text=f"Net Total:  ₹{tot:,.2f}")
        except Exception:
            self.lbl_da .config(text="Discount:  ₹0.00")
            self.lbl_tot.config(text="Net Total:  ₹0.00")
 
    def _build_med(self):
        name = self.v_name.get().strip()
        if not name:
            raise ValueError("Medicine name cannot be empty.")
        price = float(self.v_price.get() or 0)
        disc  = float(self.v_disc .get() or 0)
        stock = int  (self.v_stock.get() or 0)
        da, tot = calc(price, disc)
        return {
            "name":    name,
            "company": self.v_co .get().strip(),
            "category":self.v_cat.get().strip(),
            "price":   price, "discount": disc,
            "disc_amt":da,    "total":    tot,
            "stock":   stock,
            "mfg":     self.v_mfg.get().strip(),
            "exp":     self.v_exp.get().strip(),
        }
 
    def add(self):
        try:
            db_add(self._build_med())
            self.refresh()
            self.clear()
            self._toast("✅  Medicine added!")
        except Exception as e:
            messagebox.showerror("Input Error", str(e))
 
    def update(self):
        if self.sel_id is None:
            messagebox.showwarning("Select First", "Click a row in the table first.")
            return
        try:
            db_update(self.sel_id, self._build_med())
            self.refresh()
            self.clear()
            self._toast("✏️  Record updated.")
        except Exception as e:
            messagebox.showerror("Input Error", str(e))
 
    def delete(self):
        if self.sel_id is None:
            messagebox.showwarning("Select First", "Click a row in the table first.")
            return
        if messagebox.askyesno("Confirm Delete",
                               "Permanently delete this medicine record?",
                               icon="warning"):
            db_delete(self.sel_id)
            self.refresh()
            self.clear()
            self._toast("🗑️  Record deleted.")
 
    def refresh(self):
        self._fill(db_all())
 
    def _search(self, *_):
        kw = self.v_srch.get().strip()
        self._fill(db_search(kw) if kw else db_all())
 
    def _fill(self, rows):
        for r in self.tree.get_children():
            self.tree.delete(r)
        tot_stock = tot_val = 0
        for r in rows:
            # DB: 0=id 1=name 2=co 3=cat 4=price 5=disc 6=disc_amt 7=total 8=stock 9=mfg 10=exp
            self.tree.insert("", "end", values=(
                r[0], r[1], r[2], r[3],
                f"{r[4]:.2f}",
                f"{r[5]:.1f}",
                f"{r[6]:.2f}",
                f"{r[7]:.2f}",
                r[8], r[9], r[10]
            ))
            tot_stock += (r[8] or 0)
            tot_val   += (r[7] or 0)
        self.lbl_stats.config(
            text=f"  {len(rows)} records  │  "
                 f"Total Stock: {tot_stock} units  │  "
                 f"Inventory Value: ₹{tot_val:,.2f}")
 
    def _on_select(self, *_):
        sel = self.tree.selection()
        if not sel:
            return
        # tree values: 0=id 1=name 2=co 3=cat 4=price 5=disc 6=da 7=tot 8=stock 9=mfg 10=exp
        v = self.tree.item(sel[0], "values")
        self.sel_id = int(v[0])
        self.v_name .set(v[1])
        self.v_co   .set(v[2])
        self.v_cat  .set(v[3])
        self.v_price.set(v[4])
        self.v_disc .set(v[5])
        self.v_stock.set(v[8])
        self.v_mfg  .set(v[9])
        self.v_exp  .set(v[10])
 
    def clear(self):
        self.sel_id = None
        for v in [self.v_name, self.v_co, self.v_cat,
                  self.v_price, self.v_stock, self.v_exp]:
            v.set("")
        self.v_disc.set("0")
        self.v_mfg .set(str(datetime.date.today()))
        if self.tree.selection():
            self.tree.selection_remove(self.tree.selection())
 
    def _sort(self, col):
        rows = [(self.tree.set(r, col), r) for r in self.tree.get_children()]
        try:    rows.sort(key=lambda x: float(x[0]))
        except: rows.sort()
        for i, (_, r) in enumerate(rows):
            self.tree.move(r, "", i)
 
    def _toast(self, msg):
        """Brief green status message in the stats bar."""
        prev = self.lbl_stats.cget("text")
        self.lbl_stats.config(text=f"  {msg}", fg=SAGE)
        self.root.after(2500,
                        lambda: self.lbl_stats.config(fg=SUBTEXT, text=prev))
 
 
# ════════════════════════════════════════════════════════════
if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
